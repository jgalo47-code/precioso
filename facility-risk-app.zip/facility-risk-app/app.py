import streamlit as st
from modules import data_processing as dp
from modules import exploratory_analysis as eda
from modules import prediction as pred
from modules import dashboard as dash

st.set_page_config(page_title="Facility Reservation Risk System", layout="wide")

if "df" not in st.session_state:
    st.session_state["df"] = dp.load_sample()
    st.session_state["source"] = "built-in synthetic sample"

menu = st.sidebar.selectbox("Module", ["Home", "Dataset", "Data Analysis",
                                       "Prediction", "Dashboard", "System Design"])
role = st.sidebar.selectbox("Your role", ["Facility Administrator", "Student / Organizer",
                                          "System Administrator"])
st.sidebar.caption(f"Data in use: {st.session_state['source']}")
df = st.session_state["df"]

if menu == "Home":
    st.title("Campus Facility Reservation Monitoring")
    st.write("Predicts which reservations are likely to be **cancelled or become no-shows**, "
             "so a Facility Administrator can follow up early.")
    st.markdown("**Workflow:** Dataset -> Data Analysis -> Prediction -> Dashboard -> Human decision")
    st.info("Predictions are decision support. They never automatically reject a "
            "reservation or deny a student service.")

elif menu == "Dataset":
    st.header("Dataset upload and validation")
    up = st.file_uploader("Upload CSV", type="csv")
    if up is not None:
        try:
            new = dp.load_csv(up)
        except Exception as e:
            st.error(f"Could not read the file as CSV: {e}")
            new = None
        if new is not None:
            errors, warns = dp.validate(new)
            for e in errors: st.error(e)
            for w in warns: st.warning(w)
            if not errors:
                new = dp.prepare(new)
                st.session_state["df"], st.session_state["source"] = new, up.name
                df = new
                st.success(f"Loaded {up.name}")
    if st.button("Reset to built-in sample"):
        st.session_state["df"], st.session_state["source"] = dp.load_sample(), "built-in synthetic sample"
        st.rerun()
    s = dp.quality_summary(df)
    c = st.columns(4)
    c[0].metric("Rows", s["rows"]); c[1].metric("Columns", s["columns"])
    c[2].metric("Duplicate rows", s["duplicate_rows"]); c[3].metric("Null cells", s["null_cells"])
    if len(s["nulls_per_column"]): st.write("Nulls per column", s["nulls_per_column"])
    st.dataframe(df.head(20), use_container_width=True)

elif menu == "Data Analysis":
    st.header("Exploratory data analysis")
    eda.render(df)

elif menu == "Prediction":
    st.header("Predict cancellation / no-show")
    bundle = pred.load_bundle()
    with st.form("predict"):
        c1, c2 = st.columns(2)
        inp = {}
        for col in dp.NUMERIC:
            lo, hi, de = dp.LIMITS[col]
            inp[col] = c1.number_input(col.replace("_", " ").title(), lo, hi, de)
        for col in dp.CATEGORICAL:
            inp[col] = c2.selectbox(col.replace("_", " ").title(), dp.OPTIONS[col])
        go = st.form_submit_button("Predict")
    if go:
        try:
            r = pred.predict_one(bundle, inp)
            st.metric("Predicted outcome", "Likely cancel / no-show" if r["label"] else "Likely to attend")
            st.metric("Cancellation probability", f"{r['probability']:.1%}")
            st.write(f"**Risk level:** {r['risk_level']}  |  **Model version:** {r['model_version']}  "
                     f"|  **Predicted at:** {r['timestamp']}")
            st.info("Human review required: a Facility Administrator makes the final decision.")
        except Exception as e:
            st.error(f"Prediction failed: {e}")
    st.subheader("Model metrics (held-out test set from training)")
    m = bundle["metrics"]
    cols = st.columns(5)
    for col, k in zip(cols, ["accuracy", "precision", "recall", "f1", "roc_auc"]):
        col.metric(k.upper(), f"{m[k]:.2f}")
    st.write("Confusion matrix [[TN, FP], [FN, TP]]:", m["confusion_matrix"])
    st.caption("Limitations: " + bundle["limitations"])

elif menu == "Dashboard":
    st.header("Decision-support dashboard")
    dash.render(df, role)

else:
    dash.render_system_design()
