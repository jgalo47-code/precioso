"""Model loading and inference. The model is loaded once, never retrained."""
from datetime import datetime
import joblib
import pandas as pd
import streamlit as st
from modules.data_processing import FEATURES

MODEL_PATH = "models/trained_model.joblib"
HIGH, MEDIUM = 0.60, 0.35   # risk thresholds (document and justify these in your report)


@st.cache_resource
def load_bundle():
    return joblib.load(MODEL_PATH)


def risk_level(p: float) -> str:
    return "High" if p >= HIGH else "Medium" if p >= MEDIUM else "Low"


def predict_one(bundle, inputs: dict) -> dict:
    # One-row DataFrame with the EXACT training feature names/order
    row = pd.DataFrame([inputs])[FEATURES]
    pipe = bundle["pipeline"]
    p = float(pipe.predict_proba(row)[0, 1])
    return {
        "label": int(pipe.predict(row)[0]),
        "probability": p,
        "risk_level": risk_level(p),
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "model_version": bundle["version"],
    }


def predict_batch(bundle, df: pd.DataFrame):
    return bundle["pipeline"].predict_proba(df[FEATURES])[:, 1]
