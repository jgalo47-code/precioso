"""Decision-support dashboard, review queue, human decisions, and SAD page."""
from datetime import datetime
import pandas as pd
import plotly.express as px
import streamlit as st
from modules import prediction as pred
from modules.data_processing import TARGET

ACTIONS = {
    "High": "Contact organizer to confirm; keep a waitlist ready; consider a reminder or deposit.",
    "Medium": "Send an automatic reminder 48 hours before the slot.",
    "Low": "No action needed.",
}


def render(df: pd.DataFrame, role: str):
    bundle = pred.load_bundle()
    d = df.copy()
    if "Approval_Status" in d.columns:
        d = d[d["Approval_Status"] == "Approved"]
        st.caption("Showing approved reservations only (the model scores approved bookings).")
    d["risk_probability"] = pred.predict_batch(bundle, d)
    d["risk_level"] = d["risk_probability"].map(pred.risk_level)

    st.subheader("Key indicators")
    k = st.columns(4)
    k[0].metric("Reservations", len(d))
    k[1].metric("High-risk", int((d.risk_level == "High").sum()))
    k[2].metric("Avg predicted risk", f"{d.risk_probability.mean():.0%}")
    if TARGET in d.columns:
        k[3].metric("Actual cancel rate", f"{d[TARGET].mean():.0%}")
    else:
        k[3].metric("Actual cancel rate", "n/a")

    st.subheader("Facility risk and utilization")
    fac = (d.groupby("Facility_Type")
             .agg(reservations=("Reservation_ID", "count"),
                  hours_booked=("Duration_Hours", "sum"),
                  avg_risk=("risk_probability", "mean")).reset_index())
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(fac, x="Facility_Type", y="hours_booked", title="Hours booked (utilization)"),
                    use_container_width=True)
    c2.plotly_chart(px.bar(fac, x="Facility_Type", y="avg_risk", title="Average predicted risk",
                           range_y=[0, 1]), use_container_width=True)
    worst = fac.sort_values("avg_risk", ascending=False).iloc[0]
    st.info(f"Interpretation: **{worst.Facility_Type}** has the highest average predicted "
            f"risk ({worst.avg_risk:.0%}). Hours booked there may be wasted if not followed up.")

    st.subheader("Review queue (highest risk first)")
    level = st.multiselect("Risk level", ["High", "Medium", "Low"], default=["High"])
    queue = d[d.risk_level.isin(level)].sort_values("risk_probability", ascending=False)
    queue["recommended_follow_up"] = queue.risk_level.map(ACTIONS)
    st.dataframe(queue.head(50), use_container_width=True)

    st.subheader("Record final human decision")
    if role != "Facility Administrator":
        st.warning("Only a Facility Administrator can record decisions. "
                   "Change the role in the sidebar.")
        return
    st.caption("The model only recommends. The administrator decides.")
    if queue.empty:
        st.write("Nothing in the queue for the chosen filter.")
        return
    rid = st.selectbox("Reservation ID", queue.Reservation_ID.head(50))
    decision = st.selectbox("Decision", ["Confirmed with organizer", "Reminder sent",
                                         "Waitlist offered", "No action"])
    note = st.text_input("Note (optional)")
    if st.button("Save decision"):
        st.session_state.setdefault("decisions", []).append({
            "Reservation_ID": rid, "decision": decision, "note": note,
            "decided_by": role, "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
        st.success("Decision recorded.")
    if st.session_state.get("decisions"):
        log = pd.DataFrame(st.session_state["decisions"])
        st.dataframe(log, use_container_width=True)
        st.download_button("Download decision log", log.to_csv(index=False), "decisions.csv")


def render_system_design():
    st.header("System Design (SAD integration)")
    st.subheader("Actors")
    st.markdown("- **Student / Organizer** - submits reservations, receives reminders.\n"
                "- **Facility Administrator** - views predictions, reviews the queue, "
                "records the final decision.\n"
                "- **System Administrator** - uploads data, maintains/redeploys the model.")
    st.subheader("Functional requirements")
    st.markdown("1. FR1 - The system shall accept a CSV of reservations and validate its schema.\n"
                "2. FR2 - The system shall show descriptive statistics, class distribution and interactive charts.\n"
                "3. FR3 - The system shall predict cancellation/no-show probability for a new reservation.\n"
                "4. FR4 - The system shall list reservations in a risk-ranked review queue with recommended follow-up.\n"
                "5. FR5 - The system shall let only a Facility Administrator record and export the final decision.")
    st.subheader("Non-functional requirements")
    st.markdown("1. NFR1 - Performance: predictions return in under 3 seconds (model loaded once and cached).\n"
                "2. NFR2 - Privacy: only synthetic or authorized data; no personal identifiers in the repository.\n"
                "3. NFR3 - Transparency: model version, timestamp, limitations and human-review notice are always shown.")
    st.subheader("Updated use case diagram")
    st.image("assets/use_case_diagram.png")
    st.subheader("Analytical process / decision workflow")
    st.graphviz_chart("""
    digraph G { rankdir=LR; node [shape=box, style=rounded];
      "Upload / select reservations" -> "Validate schema";
      "Validate schema" -> "Saved pipeline predicts risk";
      "Saved pipeline predicts risk" -> "Risk-ranked review queue";
      "Risk-ranked review queue" -> "Administrator reviews";
      "Administrator reviews" -> "Final human decision logged";
      "Final human decision logged" -> "Follow-up (reminder / waitlist)"; }
    """)
