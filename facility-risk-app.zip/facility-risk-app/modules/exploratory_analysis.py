"""EDA: descriptive stats, class distribution and interactive Plotly charts."""
import pandas as pd
import plotly.express as px
import streamlit as st
from modules.data_processing import TARGET, NUMERIC, CATEGORICAL


def render(df: pd.DataFrame):
    st.subheader("Descriptive statistics")
    st.dataframe(df[NUMERIC].describe().T, use_container_width=True)

    if TARGET not in df.columns:
        st.warning(f"Add a '{TARGET}' column to see class-based charts.")
        return
    d = df.copy()
    if "Usage_Status" in d.columns:
        st.subheader("Usage status (3 classes)")
        st.plotly_chart(px.histogram(d, x="Usage_Status", color="Usage_Status"), use_container_width=True)
    d["outcome"] = d[TARGET].map({0: "Used", 1: "Cancelled / no-show"})

    st.subheader("Class distribution")
    counts = d["outcome"].value_counts().reset_index()
    counts.columns = ["outcome", "count"]
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.pie(counts, names="outcome", values="count", hole=.4), use_container_width=True)
    c2.dataframe(counts, use_container_width=True)
    if d[TARGET].mean() < 0.2 or d[TARGET].mean() > 0.8:
        st.warning("Classes are imbalanced - accuracy alone can mislead; check recall/F1.")

    st.subheader("Interactive charts")
    cat = st.selectbox("Chart 1 - cancellation rate by", CATEGORICAL)
    rate = d.groupby(cat)[TARGET].mean().mul(100).reset_index(name="cancel_rate_%")
    st.plotly_chart(px.bar(rate, x=cat, y="cancel_rate_%", color=cat), use_container_width=True)

    num = st.selectbox("Chart 2 - distribution of", NUMERIC)
    st.plotly_chart(px.histogram(d, x=num, color="outcome", barmode="overlay", opacity=.65),
                    use_container_width=True)

    x, y = st.columns(2)
    xa = x.selectbox("Chart 3 - X axis", NUMERIC, index=0)
    ya = y.selectbox("Chart 3 - Y axis", NUMERIC, index=1)
    st.plotly_chart(px.scatter(d, x=xa, y=ya, color="outcome", opacity=.6,
                               hover_data=["Reservation_ID"]), use_container_width=True)
