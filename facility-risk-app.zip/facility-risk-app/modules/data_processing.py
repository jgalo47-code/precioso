"""Schema definition, CSV loading, feature derivation, validation, quality summaries.

Prediction checkpoint: an APPROVED reservation, BEFORE the event happens.
Only information known at that moment may be a feature.
Leakage columns (never used as features): Actual_Attendance, Cancellation_Days_Before,
Usage_Status (it is the answer), Approval_Status (a Rejected request is never "used").
"""
import pandas as pd
import streamlit as st

DATA_PATH = "data/facility_reservations.csv"
ID_COL = "Reservation_ID"
RAW_TARGET = "Usage_Status"          # Used / Cancelled / No-Show
TARGET = "At_Risk"                   # 1 = Cancelled or No-Show, 0 = Used

NUMERIC = ["Duration_Hours", "Participants", "Days_Before_Event", "Start_Hour"]
CATEGORICAL = ["User_Type", "Facility_Type", "Purpose", "After_Office_Hours", "Event_Weekday"]
FEATURES = NUMERIC + CATEGORICAL

# Columns an uploaded CSV must contain (Start_Hour / Event_Weekday are derived from the last two)
REQUIRED_RAW = ["User_Type", "Facility_Type", "Purpose", "After_Office_Hours", "Duration_Hours",
                "Participants", "Days_Before_Event", "Start_Time", "Event_Date"]
LEAKAGE_COLS = ["Actual_Attendance", "Cancellation_Days_Before"]

OPTIONS = {
    "User_Type": ["Student", "Faculty", "Staff", "Organization"],
    "Facility_Type": ["Auditorium", "Classroom", "Conference Room", "Multimedia Room", "Laboratory"],
    "Purpose": ["Class", "Meeting", "Seminar", "Training", "Event"],
    "After_Office_Hours": ["No", "Yes"],
    "Event_Weekday": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
}
LIMITS = {  # (min, max, default) for input widgets
    "Duration_Hours": (1.0, 4.0, 2.0),
    "Participants": (1, 100, 50),
    "Days_Before_Event": (0, 30, 14),
    "Start_Hour": (7, 18, 9),
}


def prepare(raw: pd.DataFrame) -> pd.DataFrame:
    """Add derived features (same logic used in training)."""
    df = raw.copy()
    df["Start_Hour"] = pd.to_datetime(df["Start_Time"], format="%H:%M", errors="coerce").dt.hour
    df["Event_Weekday"] = pd.to_datetime(df["Event_Date"], errors="coerce").dt.day_name()
    if RAW_TARGET in df.columns:
        df[TARGET] = df[RAW_TARGET].isin(["Cancelled", "No-Show"]).astype(int)
    if ID_COL not in df.columns:
        df.insert(0, ID_COL, [f"ROW-{i+1}" for i in range(len(df))])
    return df


@st.cache_data
def load_csv(file) -> pd.DataFrame:
    """Read the raw CSV only (validated before prepare())."""
    return pd.read_csv(file)


@st.cache_data
def load_sample() -> pd.DataFrame:
    return prepare(pd.read_csv(DATA_PATH))


def validate(raw: pd.DataFrame):
    """Return (errors, warnings). Errors block use of the dataset."""
    errors, warnings = [], []
    if raw.empty:
        return ["The file is empty (0 rows)."], warnings
    missing = [c for c in REQUIRED_RAW if c not in raw.columns]
    if missing:
        return [f"Missing required columns: {missing}"], warnings
    for c in ["Duration_Hours", "Participants", "Days_Before_Event"]:
        if not pd.api.types.is_numeric_dtype(raw[c]):
            errors.append(f"Column '{c}' must be numeric.")
    if errors:
        return errors, warnings
    p = prepare(raw)
    if p[["Start_Hour", "Event_Weekday"]].isna().any().any():
        errors.append("Some Start_Time (HH:MM) or Event_Date (YYYY-MM-DD) values could not be read.")
    for c in CATEGORICAL:
        unknown = set(p[c].dropna().unique()) - set(OPTIONS[c]) if c in OPTIONS else set()
        if unknown:
            warnings.append(f"'{c}' has categories not seen in training: {sorted(unknown)}.")
    leak = [c for c in LEAKAGE_COLS if c in raw.columns]
    if leak:
        warnings.append(f"Columns {leak} are only known after the event; they are ignored by the model.")
    if RAW_TARGET not in raw.columns:
        warnings.append(f"No '{RAW_TARGET}' column: class charts and actual cancel rate are unavailable.")
    return errors, warnings


def quality_summary(df: pd.DataFrame) -> dict:
    return {
        "rows": len(df),
        "columns": df.shape[1],
        "duplicate_rows": int(df.duplicated().sum()),
        "null_cells": int(df.isna().sum().sum()),
        "nulls_per_column": df.isna().sum()[lambda s: s > 0],
    }
