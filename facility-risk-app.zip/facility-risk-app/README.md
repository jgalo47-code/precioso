# Campus Facility Reservation Monitoring (Streamlit)
Predicts cancellation / no-show risk for facility reservations and supports Facility Administrator review.
Predictions are decision support only; a human records every final decision.

## Run locally
    pip install -r requirements.txt
    python train_model.py      # replace with your midterm training code; writes models/trained_model.joblib
    python make_diagram.py     # use case diagram
    streamlit run app.py

## Structure
app.py, modules/ (data_processing, exploratory_analysis, prediction, dashboard), models/, data/, assets/

## Data
Synthetic data only. No student records are committed.
