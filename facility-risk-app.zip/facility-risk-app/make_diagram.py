import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle
fig, ax = plt.subplots(figsize=(11, 7)); ax.axis("off"); ax.set_xlim(0, 11); ax.set_ylim(0, 7)
ax.add_patch(Rectangle((3, .3), 5.2, 6.4, fill=False, lw=1.5))
ax.text(5.6, 6.45, "Facility Reservation Risk System", ha="center", weight="bold")
cases = {"Upload & validate dataset": 5.6, "View EDA charts": 4.7, "Predict cancellation risk": 3.8,
         "View risk dashboard / queue": 2.9, "Record final decision": 2.0, "Maintain / redeploy model": 1.1}
pos = {}
for t, y in cases.items():
    ax.add_patch(Ellipse((5.6, y), 3.6, .7, fill=False)); ax.text(5.6, y, t, ha="center", va="center", fontsize=9)
    pos[t] = y
actors = {"Student /\nOrganizer": (1, 4.3), "Facility\nAdministrator": (1, 2.4), "System\nAdministrator": (10, 3.4)}
links = {"Student /\nOrganizer": ["Predict cancellation risk"],
         "Facility\nAdministrator": ["View EDA charts", "Predict cancellation risk", "View risk dashboard / queue",
                                     "Record final decision"],
         "System\nAdministrator": ["Upload & validate dataset", "Maintain / redeploy model", "View EDA charts"]}
for a, (x, y) in actors.items():
    ax.plot([x], [y + .35], "o", ms=14, mfc="white", mec="k"); ax.plot([x, x], [y + .2, y - .3], "k")
    ax.text(x, y - .75, a, ha="center", fontsize=9)
    for u in links[a]:
        tx = 3.8 if x < 5 else 7.4
        ax.plot([x + (.3 if x < 5 else -.3), tx], [y, pos[u]], "k", lw=.8)
plt.savefig("assets/use_case_diagram.png", dpi=150, bbox_inches="tight")
