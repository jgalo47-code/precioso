"""Training script built from the facility_reservations.csv dataset.
Replace the model section with the exact code from YOUR midterm notebook if it differs,
but keep the feature list in modules/data_processing.py in sync and keep the final joblib.dump."""
from datetime import date
import joblib, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from modules.data_processing import (CATEGORICAL, DATA_PATH, FEATURES, NUMERIC, TARGET, prepare)

# 1. Data: approved reservations only (a rejected request can never be "used")
df = prepare(pd.read_csv(DATA_PATH))
df = df[df["Approval_Status"] == "Approved"].reset_index(drop=True)
X, y = df[FEATURES], df[TARGET]
print("Rows:", len(df), "| at-risk share:", round(y.mean(), 3))

# 2. One pipeline = preprocessing + model, saved together
pre = ColumnTransformer([
    ("num", SimpleImputer(strategy="median"), NUMERIC),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                      ("oh", OneHotEncoder(handle_unknown="ignore"))]), CATEGORICAL)])
pipe = Pipeline([("pre", pre),
                 ("clf", RandomForestClassifier(n_estimators=300, min_samples_leaf=5,
                                                class_weight="balanced", random_state=42))])
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, stratify=y, random_state=42)
pipe.fit(Xtr, ytr)
pred, proba = pipe.predict(Xte), pipe.predict_proba(Xte)[:, 1]
metrics = dict(accuracy=accuracy_score(yte, pred), precision=precision_score(yte, pred, zero_division=0),
               recall=recall_score(yte, pred), f1=f1_score(yte, pred),
               roc_auc=roc_auc_score(yte, proba),
               confusion_matrix=confusion_matrix(yte, pred).tolist())
print(metrics)

# 3. Save once; the app never retrains
joblib.dump({"pipeline": pipe, "metrics": metrics, "features": FEATURES,
             "version": f"v1.0 ({date.today()})",
             "limitations": "Small dataset (about 350 approved reservations); no weather, exam-period or "
                            "holiday information; probabilities are uncalibrated estimates. Use only to "
                            "prioritise human follow-up, never to reject a reservation."},
            "models/trained_model.joblib")
